import pygame
import math
import random
import sys
import os
import argparse
import numpy as np

class Config:
    BASE_WIDTH = 1200
    BASE_HEIGHT = 600
    FPS = 60
    AUTO_ADVANCE_MS = 30000
    TITLE_TIME_MS = 30000
    CREDITS_TIME_MS = 18000
    FULLSCREEN = False
    WIDTH = 0
    HEIGHT = 0
    CENTER = (0, 0)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--fullscreen', action='store_true')
    args = parser.parse_args()
    Config.FULLSCREEN = args.fullscreen

def clamp(v, min_v=0, max_v=255):
    return max(min_v, min(max_v, int(v)))

class AudioSystem:
    def __init__(self):
        self.mixer_avail = False
        self.mod_loaded = False
        self.explosion_sound = None
        self.countdown_sounds = {}
        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)
            self.mixer_avail = True
            self._load_music()
            self._generate_sounds()
        except Exception:
            pass

    def _load_music(self):
        paths = [
            "elimination.mod",
            os.path.join(os.path.dirname(__file__), "elimination.mod"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "elimination.mod"),
        ]
        for path in paths:
            if os.path.exists(path):
                try:
                    pygame.mixer.music.load(path)
                    pygame.mixer.music.set_volume(0.7)
                    self.mod_loaded = True
                    break
                except:
                    continue

    def _generate_sounds(self):
        self.countdown_sounds = {
            5: self._create_beep(220),
            4: self._create_beep(261),
            3: self._create_beep(329),
            2: self._create_beep(392),
            1: self._create_beep(523),
        }
        self.explosion_sound = self._create_explosion()

    def _create_beep(self, frequency, duration=0.25):
        if not self.mixer_avail:
            return None
        sample_rate = 22050
        num_samples = int(sample_rate * duration)
        t = np.linspace(0, duration, num_samples)
        freq_sweep = np.linspace(frequency, frequency * 1.4, num_samples)
        wave = np.sin(2 * np.pi * freq_sweep * t)
        envelope = np.exp(-6 * t)
        wave = (wave * envelope * 0.5)
        noise_burst = np.random.uniform(-0.1, 0.1, 200)
        wave[:200] += noise_burst
        sound_wave = (wave * 32767).astype(np.int16)
        stereo_wave = np.column_stack((sound_wave, sound_wave))
        return pygame.sndarray.make_sound(stereo_wave)

    def _create_explosion(self):
        if not self.mixer_avail:
            return None
        try:
            sample_rate = 44100
            duration = 3.0
            num_samples = int(sample_rate * duration)
            samples = []
            for i in range(num_samples):
                t = i / sample_rate
                if t < 0.03:
                    envelope = min(1.0, t * 50)
                elif t < 0.1:
                    envelope = math.exp(-t * 30) * 1.2
                elif t < 0.5:
                    envelope = math.exp(-t * 6) * 0.9
                elif t < 1.5:
                    envelope = math.exp(-t * 2) * 0.6
                else:
                    envelope = math.exp(-t * 0.8) * 0.4
                rumble = math.sin(2 * math.pi * (15 + 10 * math.sin(t * 2)) * t) * 1.0
                blast = math.sin(2 * math.pi * (200 * math.exp(-t * 8) + 40) * t) * 0.8
                punch = math.sin(2 * math.pi * (120 * (1 - t * 0.6)) * t * (1 + 0.3 * math.sin(t * 50))) * 0.7
                shatter = math.sin(2 * math.pi * (1500 * math.exp(-t * 25) + 500) * t) * 0.6 * math.exp(-t * 40)
                noise1 = (random.random() * 2 - 1) * 1.5 * (1 - t/0.1) if t < 0.1 else 0
                noise2 = (random.random() * 2 - 1) * 0.8 * math.exp(-t * 4) if t < 1.0 else (random.random() * 2 - 1) * 0.3 * math.exp(-t * 2)
                noise3 = (random.random() * 2 - 1) * 0.6 * math.exp(-t * 1.5) * (0.5 + 0.5 * math.sin(t * 80)) if 0.2 < t < 2.0 else 0
                low_noise = (random.random() * 2 - 1) * 0.4 * math.exp(-t * 1.2) * (0.3 + 0.7 * math.exp(-t * 3)) if t > 0.1 else 0
                transient = (random.random() * 2 - 1) * 2.0 * (1 - t/0.015) if t < 0.015 else 0
                reverb = 0
                for delay in [50, 120, 300, 600]:
                    if i > delay:
                        reverb += samples[(i-delay)*2] / 32767 * 0.25 * math.exp(-t * 8)
                combined = (rumble + blast + punch + shatter + noise1 + noise2 + noise3 + low_noise + transient + reverb) * envelope
                combined = max(min(combined, 1.2), -1.2)
                if combined > 0.9:
                    combined = 0.9 + (combined - 0.9) * 0.7
                elif combined < -0.9:
                    combined = -0.9 + (combined + 0.9) * 0.7
                sample_int = int(max(min(combined * 32767, 32767), -32768))
                samples.append(sample_int & 0xFF)
                samples.append((sample_int >> 8) & 0xFF)
            sound = pygame.mixer.Sound(buffer=bytes(samples))
            sound.set_volume(1.0)
            return sound
        except:
            return None

    def play_music(self):
        if self.mod_loaded:
            pygame.mixer.music.play(-1)

    def stop_music(self):
        if self.mod_loaded:
            pygame.mixer.music.stop()

    def fadeout_music(self, ms):
        if self.mod_loaded:
            pygame.mixer.music.fadeout(ms)

    def toggle_pause(self):
        if self.mod_loaded:
            if pygame.mixer.music.get_busy():
                pygame.mixer.music.pause()
            else:
                pygame.mixer.music.unpause()

    def adjust_volume(self, delta):
        if self.mod_loaded:
            v = pygame.mixer.music.get_volume()
            pygame.mixer.music.set_volume(max(0.0, min(1.0, v + delta)))

    def play_countdown(self, num):
        if num in self.countdown_sounds and self.countdown_sounds[num]:
            self.countdown_sounds[num].play()

    def play_explosion(self):
        if self.explosion_sound:
            self.explosion_sound.play()

class EffectBase:
    def draw(self, surface, t):
        pass

class ExplosionParticle:
    def __init__(self, x, y, w, h):
        self.x, self.y = x, y
        angle = random.uniform(0, 2 * math.pi)
        speed = random.uniform(5, 25)
        self.vx, self.vy = math.cos(angle) * speed, math.sin(angle) * speed
        self.gravity, self.friction = 0.5, 0.95
        self.size = random.randint(5, 20)
        self.colour = random.choice([(255, 255, 255), (255, 220, 100), (255, 150, 50),
                                   (255, 100, 50), (255, 200, 0), (255, 255, 200), (255, 100, 100)])
        self.alpha = 255
        self.fade_rate = random.uniform(1.5, 4)
        self.rotation = random.uniform(0, 360)
        self.rot_speed = random.uniform(-20, 20)
        self.trail = []
        self.pulse_speed = random.uniform(0.05, 0.15)

    def update(self):
        curr_size = self.size * (0.8 + 0.4 * math.sin(pygame.time.get_ticks() * self.pulse_speed))
        self.trail.append((self.x, self.y, self.alpha, curr_size))
        if len(self.trail) > 15:
            self.trail.pop(0)
        self.x += self.vx
        self.y += self.vy
        self.vy += self.gravity
        self.vx *= self.friction
        self.vy *= self.friction
        self.rotation += self.rot_speed
        self.alpha = max(0, self.alpha - self.fade_rate)
        return self.alpha > 0

    def draw(self, surface):
        if self.alpha <= 0:
            return
        curr_size = self.size * (0.8 + 0.4 * math.sin(pygame.time.get_ticks() * self.pulse_speed))
        for i, (tx, ty, ta, ts) in enumerate(self.trail):
            ta = int(ta * (i / len(self.trail)) * 0.7)
            if ta > 0:
                ds = max(1, int(ts * (i / len(self.trail)) * 1.5))
                s = pygame.Surface((ds * 2, ds * 2), pygame.SRCALPHA)
                pygame.draw.circle(s, (*self.colour, ta), (ds, ds), ds)
                surface.blit(s, (int(tx) - ds, int(ty) - ds))
        glow_size = curr_size * 3
        gs = pygame.Surface((glow_size * 2, glow_size * 2), pygame.SRCALPHA)
        pygame.draw.circle(gs, (*self.colour, int(self.alpha * 0.5)), (glow_size, glow_size), glow_size)
        surface.blit(gs, (int(self.x) - glow_size, int(self.y) - glow_size), special_flags=pygame.BLEND_ADD)
        g2s = curr_size * 2
        gs2 = pygame.Surface((g2s * 2, g2s * 2), pygame.SRCALPHA)
        pygame.draw.circle(gs2, (255, 255, 200, int(self.alpha * 0.7)), (g2s, g2s), g2s)
        surface.blit(gs2, (int(self.x) - g2s, int(self.y) - g2s), special_flags=pygame.BLEND_ADD)
        ps = pygame.Surface((int(curr_size * 2), int(curr_size * 2)), pygame.SRCALPHA)
        pygame.draw.circle(ps, (*self.colour, int(self.alpha)), (int(curr_size), int(curr_size)), int(curr_size))
        pygame.draw.circle(ps, (255, 255, 255, int(self.alpha * 0.8)), (int(curr_size * 0.7), int(curr_size * 0.7)), max(1, int(curr_size * 0.4)))
        if self.rot_speed != 0:
            rs = pygame.transform.rotate(ps, self.rotation)
            surface.blit(rs, (int(self.x) - rs.get_width() // 2, int(self.y) - rs.get_height() // 2), special_flags=pygame.BLEND_ADD)
        else:
            surface.blit(ps, (int(self.x) - curr_size, int(self.y) - curr_size), special_flags=pygame.BLEND_ADD)

class HardcoreRubberDeformer(EffectBase):
    def __init__(self):
        self.lat_steps = 15
        self.lon_steps = 15
        self.radius = 195
        self.base_vertices = []
        self.faces = []
        for i in range(self.lat_steps + 1):
            lat = math.pi * i / self.lat_steps
            for j in range(self.lon_steps):
                lon = 2 * math.pi * j / self.lon_steps
                x = math.sin(lat) * math.cos(lon)
                y = math.sin(lat) * math.sin(lon)
                z = math.cos(lat)
                self.base_vertices.append([x, y, z])
        self.base_vertices = np.array(self.base_vertices)
        for i in range(self.lat_steps):
            for j in range(self.lon_steps):
                p1 = i * self.lon_steps + j
                p2 = i * self.lon_steps + (j + 1) % self.lon_steps
                p3 = (i + 1) * self.lon_steps + (j + 1) % self.lon_steps
                p4 = (i + 1) * self.lon_steps + j
                self.faces.append([p1, p2, p3, p4])
        self.pos = np.array([Config.WIDTH/2, Config.HEIGHT/2, 0.0])
        self.vel = np.array([6.0, 4.5, 0.0])
        self.rot = np.array([0.0, 0.0, 0.0])
        self.rot_vel = np.array([0.015, 0.02, 0.01])
        self.impact_sq = np.array([0.0, 0.0, 0.0])
        self.color_red = np.array([190, 30, 30])
        self.color_grey = np.array([90, 90, 90])
        self.light_dir = np.array([0.5, -0.7, -1.0])
        self.light_dir /= np.linalg.norm(self.light_dir)

    def _draw_sine_bars(self, surface, t):
        num_bars = 12
        bar_height = 45
        for i in range(num_bars):
            y_offset = math.sin(t * 0.001 + i * 0.5) * 110
            y_offset += math.cos(t * 0.0008 + i * 0.8) * 60
            center_y = (Config.HEIGHT / 2) + y_offset
            color_factor = (math.sin(t * 0.002 + i * 0.3) + 1) / 2
            base_col = self.color_red * color_factor + self.color_grey * (1 - color_factor)
            for layer in range(3):
                h = bar_height - (layer * 12)
                alpha_col = [clamp(c * (1 - layer * 0.25)) for c in base_col]
                rect = pygame.Rect(0, center_y - h/2, Config.WIDTH, h)
                pygame.draw.rect(surface, alpha_col, rect)

    def _draw_weather_ui(self, surface, wind, t):
        font = pygame.font.SysFont("Courier New", 16, bold=True)
        wind_speed = np.linalg.norm(wind) * 45.2
        g_force = 1.0 + (np.linalg.norm(self.impact_sq) * 12.0)
        stability = 100 - (np.sum(self.impact_sq) * 400)
        lines = [
            f"WIND_VELOCITY: {wind_speed:.1f} KPH",
            f"IMPACT_FORCE: {g_force:.2f} G",
            f"SURFACE_STABILITY: {max(0, stability):.1f}%",
        ]
        for i, line in enumerate(lines):
            text_surf = font.render(line, True, (255, 50, 50))
            surface.blit(text_surf, (22, 22 + i * 22))
            text_surf = font.render(line, True, (200, 200, 200))
            surface.blit(text_surf, (20, 20 + i * 22))

    def _get_rotation_matrix(self, r):
        cx, sx = math.cos(r[0]), math.sin(r[0])
        cy, sy = math.cos(r[1]), math.sin(r[1])
        cz, sz = math.cos(r[2]), math.sin(r[2])
        return np.array([
            [cy*cz, -cy*sz, sy],
            [sx*sy*cz + cx*sz, -sx*sy*sz + cx*cz, -sx*cy],
            [-cx*sy*cz + sx*sz, cx*sy*sz + sx*cz, cx*cy]
        ])

    def draw(self, surface, t):
        surface.fill((15, 15, 20))
        self._draw_sine_bars(surface, t)
        wind = np.array([math.sin(t*0.0015)*1.6, math.cos(t*0.001)*1.1, 0])
        self.vel += wind * 0.12
        self.pos += self.vel
        self.rot += self.rot_vel
        self.impact_sq *= 0.86
        margin = self.radius + 5
        for i in range(2):
            limit = Config.WIDTH if i == 0 else Config.HEIGHT
            if self.pos[i] < margin or self.pos[i] > limit - margin:
                self.vel[i] *= -0.92
                self.impact_sq[i] = abs(self.vel[i]) * 0.28
                self.pos[i] = clamp(self.pos[i], margin, limit - margin)
        rot_mat = self._get_rotation_matrix(self.rot)
        wobble = math.sin(t * 0.006) * 0.12
        deformed = self.base_vertices.copy()
        deformed[:, 0] *= (1.0 - self.impact_sq[0])
        deformed[:, 1] *= (1.0 - self.impact_sq[1])
        for i in range(len(deformed)):
            dot_wind = np.dot(self.base_vertices[i], wind * 0.09)
            v_wobble = math.sin(self.base_vertices[i,1]*6 + t*0.008) * wobble
            deformed[i] *= (1.0 + dot_wind + v_wobble)
        transformed = np.dot(deformed * self.radius, rot_mat.T)
        render_list = []
        for f in self.faces:
            v = [transformed[idx] for idx in f]
            norm = np.cross(v[1]-v[0], v[2]-v[0])
            if norm[2] < 0:
                n_unit = norm / (np.linalg.norm(norm) + 1e-6)
                lum = np.dot(n_unit, self.light_dir)
                shade = (lum + 1) / 2
                color = self.color_red * (shade**1.2) + self.color_grey * (1 - shade)
                stress = (self.impact_sq[0] + self.impact_sq[1]) * 180
                final_color = [clamp(c + stress) for c in color]
                z_avg = sum(p[2] for p in v) / 4
                pts = [(self.pos[0] + p[0], self.pos[1] + p[1]) for p in v]
                render_list.append((z_avg, pts, final_color))
        render_list.sort(key=lambda x: x[0], reverse=True)
        for _, pts, col in render_list:
            pygame.draw.polygon(surface, col, pts)
            pygame.draw.polygon(surface, [clamp(c + 25) for c in col], pts, 1)
        self._draw_weather_ui(surface, wind, t)

class AdvancedPlasma(EffectBase):
    def __init__(self):
        self.p_size = (60, 30)
        self.surf = pygame.Surface(self.p_size)
        self.font = pygame.font.SysFont("Courier New", 350, bold=True)
        self.chars = list(" BEWARE - CHANGING WEATHER AHEAD    ")
        self.char_surfs = [self.font.render(c, True, (255, 255, 200)) for c in self.chars]
        self.char_widths = [s.get_width() for s in self.char_surfs]
        self.total_width = sum(self.char_widths)
        self.scroll = Config.WIDTH
        self.rain = [{'x': random.randint(0, Config.WIDTH), 'y': random.randint(0, Config.HEIGHT), 's': random.uniform(15, 25), 'l': random.randint(10, 20)} for _ in range(120)]
        self.flash = 0
        self.st = None

    def draw(self, surface, t):
        if self.st is None:
            self.st = t
        elapsed = t - self.st
        weather_factor = 0.0
        if 10000 <= elapsed < 12000:
            weather_factor = (elapsed - 10000) / 2000.0
        elif 12000 <= elapsed < 22000:
            weather_factor = 1.0
        elif 22000 <= elapsed < 24000:
            weather_factor = 1.0 - ((elapsed - 22000) / 2000.0)
        elif elapsed >= 24000:
            weather_factor = 0.0
        if weather_factor < 0.1 and random.random() < 0.01:
            self.flash = 255
        for x in range(self.p_size[0]):
            for y in range(self.p_size[1]):
                v = math.sin(x * 0.1 + t * 0.005) + math.sin((y * 0.1 + t * 0.005) * 0.5) + math.sin((x * 0.1 + y * 0.1 + t * 0.005) * 0.5)
                v += math.sin(math.sqrt((x + 0.5 * math.sin(t * 0.002))**2 + (y + 0.5 * math.cos(t * 0.003))**2 + 1) * 0.1)
                n = (v + 2) / 4
                r1, g1, b1 = 20 + 60 * n + (self.flash * 0.4), 30 + 70 * n + (self.flash * 0.4), 60 + 140 * n + self.flash
                r2, g2, b2 = 200 + 55 * n, 120 + 100 * n, 40 + 60 * n
                r = clamp(r1 * (1 - weather_factor) + r2 * weather_factor)
                g = clamp(g1 * (1 - weather_factor) + g2 * weather_factor)
                b = clamp(b1 * (1 - weather_factor) + b2 * weather_factor)
                self.surf.set_at((x, y), (r, g, b))
        surface.blit(pygame.transform.scale(self.surf, (Config.WIDTH, Config.HEIGHT)), (0, 0))
        rain_alpha = int(255 * (1 - weather_factor))
        if rain_alpha > 0:
            for r in self.rain:
                r['y'] += r['s']
                r['x'] += 6
                if r['y'] > Config.HEIGHT:
                    r['y'] = -20
                    r['x'] = random.randint(-100, Config.WIDTH)
                rain_line = pygame.Surface((10, r['l'] + 10), pygame.SRCALPHA)
                pygame.draw.line(rain_line, (140, 150, 190, rain_alpha), (0, 0), (6, r['l']), 1)
                surface.blit(rain_line, (r['x'], r['y']))
            if self.flash > 0:
                fs = pygame.Surface((Config.WIDTH, Config.HEIGHT))
                fs.fill((220, 230, 255))
                fs.set_alpha(int(self.flash * 0.3 * (1 - weather_factor)))
                surface.blit(fs, (0, 0))
                self.flash = max(0, self.flash - 20)
        if weather_factor > 0:
            glow = pygame.Surface((600, 600), pygame.SRCALPHA)
            for i in range(150, 0, -10):
                alpha = int(100 * (i/150) * weather_factor)
                pygame.draw.circle(glow, (255, 255, 180, alpha), (300, 300), i * 2)
            surface.blit(glow, (Config.WIDTH - 450, -150), special_flags=pygame.BLEND_ADD)
        self.scroll -= 7
        if self.scroll < -self.total_width:
            self.scroll = Config.WIDTH
        cx = self.scroll
        for i, (c, cs) in enumerate(zip(self.chars, self.char_surfs)):
            if cx > Config.WIDTH + 150 or cx < -400:
                cx += self.char_widths[i]
                continue
            dy = int(Config.HEIGHT // 5 + 80 * math.sin(cx * 0.015 + t * 0.004) + 15 * math.sin(i * 0.3 + t * 0.006))
            sc = 1.0 + 0.2 * math.sin(i * 0.2 + t * 0.005)
            pulse = int(180 + 75 * math.sin(t * 0.004 + i))
            col_storm = (100, pulse, 255)
            col_sun = (255, pulse, 80)
            col = (
                int(col_storm[0]*(1-weather_factor) + col_sun[0]*weather_factor),
                int(col_storm[1]*(1-weather_factor) + col_sun[1]*weather_factor),
                int(col_storm[2]*(1-weather_factor) + col_sun[2]*weather_factor)
            )
            dcs = pygame.transform.scale(cs, (max(1, int(cs.get_width() * sc)), max(1, int(cs.get_height() * sc))))
            dcs.fill(col, special_flags=pygame.BLEND_MULT)
            surface.blit(self.font.render(c, True, (20, 20, 40)), (int(cx) + 5, dy + 5))
            surface.blit(dcs, (int(cx), dy))
            cx += self.char_widths[i]

class BouncingRadar(EffectBase):
    def __init__(self):
        self.segs = 20
        self.wpos = [[Config.WIDTH // 2, Config.HEIGHT // 2] for _ in range(self.segs)]
        self.blips = [[random.randint(0, Config.WIDTH), random.randint(0, Config.HEIGHT), random.uniform(0, math.tau), random.randint(50, 150)] for _ in range(20)]
        self.pulse = 0
        self.cc = 0

    def _calc_pos(self, pi, t, c):
        f = t * 0.001
        if pi == 0:
            return [c[0] + 250 * math.sin(3 * f), c[1] + 200 * math.sin(2 * f)]
        if pi == 1:
            return [c[0] + 280 * math.sin(5 * f * 1.2 + math.pi/4), c[1] + 180 * math.sin(4 * f * 1.2)]
        if pi == 2:
            a = f * 1.5
            r = 150 + 100 * math.sin(3 * a)
            return [c[0] + r * math.cos(a), c[1] + r * math.sin(a)]
        if pi == 3:
            return [c[0] + 220 * math.sin(f), c[1] + 160 * math.sin(2 * f + math.pi/6)]
        R, r = 120, 40
        return [c[0] + (R+r)*math.cos(f) - r*math.cos(((R+r)/r)*f), c[1] + (R+r)*math.sin(f) - r*math.sin(((R+r)/r)*f)]

    def draw(self, surface, t):
        surface.fill((0, 20, 40))
        cx, cy = Config.CENTER
        pd, ttrans = 6000, 2000
        tip = t % pd
        trans = (tip - (pd - ttrans)) / ttrans if tip >= pd - ttrans else 0
        trans = trans * trans * (3 - 2 * trans) if trans > 0 else 0
        cp, n_p = (t // pd) % 5, ((t // pd) + 1) % 5
        p1, p2 = self._calc_pos(cp, t, (cx, cy)), self._calc_pos(n_p, t, (cx, cy))
        hx = p1[0] * (1 - trans) + p2[0] * trans
        hy = p1[1] * (1 - trans) + p2[1] * trans
        self.wpos[0] = [hx, hy]
        for i in range(1, self.segs):
            dx, dy = self.wpos[i-1][0] - self.wpos[i][0], self.wpos[i-1][1] - self.wpos[i][1]
            d = math.hypot(dx, dy)
            if d > 0:
                mr = min(1.0, 20 / d)
                self.wpos[i][0] += dx * (1 - mr)
                self.wpos[i][1] += dy * (1 - mr)
        for i in range(6):
            r = 80 + i * 70
            s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
            pygame.draw.circle(s, (0, 255, 100, 90 - i * 12), (r, r), r, 2)
            surface.blit(s, (cx - r, cy - r))
        sa = (t * 0.0015) % math.tau
        ex, ey = cx + 450 * math.cos(sa), cy + 450 * math.sin(sa)
        for i in range(80):
            p = i / 80
            x1, y1 = cx + (ex - cx) * p, cy + (ey - cy) * p
            x2, y2 = cx + (ex - cx) * ((i+1)/80), cy + (ey - cy) * ((i+1)/80)
            ls = pygame.Surface((abs(x2-x1)+10, abs(y2-y1)+10), pygame.SRCALPHA)
            pygame.draw.line(ls, (0, 255, 100, int(200 * (1 - p))), (5, 5), (x2-x1+5, y2-y1+5), 2)
            surface.blit(ls, (min(x1, x2)-5, min(y1, y2)-5))
        for b in self.blips:
            if random.random() < 0.01:
                b[0] = clamp(b[0] + random.uniform(-1, 1), 0, Config.WIDTH)
                b[1] = clamp(b[1] + random.uniform(-1, 1), 0, Config.HEIGHT)
            ad = abs(sa - math.atan2(b[1] - cy, b[0] - cx))
            b[3] = min(255, b[3] + 15) if ad < 0.15 or ad > math.tau - 0.15 else max(40, b[3] - 2)
            bs = int(7 * (1.0 + 0.08 * math.sin(t * 0.008 + b[2])))
            s = pygame.Surface((bs*3, bs*3), pygame.SRCALPHA)
            pygame.draw.circle(s, (255, 255, 0, b[3]//4), (bs*1.5, bs*1.5), bs+3)
            pygame.draw.circle(s, (255, 255, 0, b[3]), (bs*1.5, bs*1.5), bs)
            surface.blit(s, (b[0]-bs*1.5, b[1]-bs*1.5))
        self.pulse += 0.03
        self.cc += 0.01
        for i in range(len(self.wpos)-1):
            pygame.draw.line(surface, (255, 100, 100), (int(self.wpos[i][0]), int(self.wpos[i][1])), (int(self.wpos[i+1][0]), int(self.wpos[i+1][1])), 30)
        for i, pos in enumerate(self.wpos):
            h = (i/len(self.wpos) + self.cc) % 1.0
            c = (int(127+127*math.sin(h*math.tau)), int(127+127*math.sin(h*math.tau+math.tau/3)), int(127+127*math.sin(h*math.tau+2*math.tau/3)))
            sz = int(20 * (1.0 + 0.15 * math.sin(self.pulse - i * 0.2)))
            gs = pygame.Surface((sz*3.6, sz*3.6), pygame.SRCALPHA)
            pygame.draw.circle(gs, (*c, 60), (int(sz*1.8), int(sz*1.8)), int(sz*1.8))
            surface.blit(gs, (int(pos[0]-sz*1.8), int(pos[1]-sz*1.8)))
            pygame.draw.circle(surface, c, (int(pos[0]), int(pos[1])), sz)
        names = ["LISSAJOUS 3:2", "LISSAJOUS 5:4", "ROSE SPIRAL", "FIGURE-8", "EPICYCLOID"]
        surface.blit(pygame.font.SysFont("Arial", 24).render(f"{names[cp]} -> {names[n_p]}" if trans > 0.1 else f"WORM PATTERN: {names[cp]}", True, (255, 200, 100) if trans > 0.1 else (0, 255, 100)), (20, 20))

class ElectricStormOrb(EffectBase):
    def __init__(self):
        self.rad = 220
        self.pts = []
        phi = math.pi * (3.0 - math.sqrt(5.0))
        for i in range(800):
            y = 1 - (i / 799.0) * 2
            r = math.sqrt(1 - y * y)
            t = phi * i
            self.pts.append([math.cos(t) * r * self.rad, y * self.rad, math.sin(t) * r * self.rad])

    def draw(self, surface, t):
        surface.fill((5, 10, 15))
        ax, ay, az = t * 0.0005, t * 0.0012, t * 0.0002
        cx, sx, cy, sy, cz, sz = math.cos(ax), math.sin(ax), math.cos(ay), math.sin(ay), math.cos(az), math.sin(az)
        cx_s, cy_s = Config.CENTER
        proj = []
        en = (math.cos(t * 0.0008), math.sin(t * 0.0012), math.sin(t * 0.0008))
        eth = 50 * math.sin(t * 0.002)
        for x, y, z in self.pts:
            y, z = y * cx - z * sx, y * sx + z * cx
            x, z = x * cy + z * sy, -x * sy + z * cy
            x, y = x * cz - y * sz, x * sz + y * cz
            ev = x * en[0] + y * en[1] + z * en[2]
            edge = abs(ev - eth) < 40
            if ev < eth:
                continue
            gs = (random.randint(-10, 10), random.randint(-10, 10)) if edge and random.random() > 0.6 else (0, 0)
            sc = 400 / (450 + z)
            proj.append([z, cx_s + int((x + gs[0]) * sc), cy_s + int((y + gs[1]) * sc), sc, edge])
        proj.sort(key=lambda p: p[0])
        for z, px, py, sc, edge in proj:
            b = max(50, min(255, int(100 + 155 * (z + self.rad) / (2 * self.rad))))
            s = max(2, int(4 * sc))
            if edge:
                pygame.draw.rect(surface, (255, random.randint(50, 200), 50), (px, py, s, s))
            else:
                pygame.draw.circle(surface, (0, b, b), (px, py), s // 2 + 1)
        for _ in range(15):
            p1, p2 = random.choice(proj), random.choice(proj)
            if p1[0] > 0 and p2[0] > 0 and math.hypot(p1[1]-p2[1], p1[2]-p2[2]) < 60:
                pygame.draw.line(surface, (0, 100, 200), (p1[1], p1[2]), (p2[1], p2[2]), 1)
        f = pygame.font.SysFont("Courier New", 24, bold=True)
        surface.blit(f.render(f"INTEGRITY: {int(len(proj)/800 * 100)}%", True, (255, 100, 100)), (20, 20))
        surface.blit(f.render(f"PACKET LOSS DETECTED{'_' if (t // 500) % 2 == 0 else ' '}", True, (255, 50, 50)), (20, 50))

class StormEye(EffectBase):
    def __init__(self):
        self.clouds = []
        for _ in range(180):
            self._add_cloud(random.uniform(10, 2000))
        self.bolts = []
        self.flash = 0
        self.sw_rad = 0
        self.sw_alpha = 0

    def _add_cloud(self, z):
        a, d = random.uniform(0, math.tau), random.uniform(110, 650)
        self.clouds.append({'x': math.cos(a)*d, 'y': math.sin(a)*d, 'z': z, 's': random.randint(70, 150), 'r': random.uniform(0, 360), 'rs': random.uniform(-1.5, 1.5), 'd': random.randint(120, 220), 'sv': [random.uniform(0.7, 1.3) for _ in range(5)]})

    def _bolt(self, x1, y1, x2, y2, d, disp):
        if d <= 0:
            return [((x1, y1), (x2, y2))]
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        l = math.hypot(x2 - x1, y2 - y1)
        nx, ny = -(y2 - y1) / l, (x2 - x1) / l
        o = random.uniform(-disp, disp)
        mx += nx * o
        my += ny * o
        s = self._bolt(x1, y1, mx, my, d - 1, disp * 0.5) + self._bolt(mx, my, x2, y2, d - 1, disp * 0.5)
        if random.random() < 0.25:
            ba = random.uniform(-0.6, 0.6)
            s += self._bolt(mx, my, mx + math.cos(math.atan2(y2-y1, x2-x1) + ba) * (l * 0.4), my + math.sin(math.atan2(y2-y1, x2-x1) + ba) * (l * 0.4), d - 1, disp * 0.4)
        return s

    def draw(self, surface, t):
        self.flash = max(0, self.flash - 12)
        ff = self.flash / 255.0
        surface.fill((min(255, 5 + int(180 * ff)), min(255, 5 + int(210 * ff)), min(255, 20 + int(255 * ff))))
        cx, cy = Config.CENTER
        tr = t * 0.0006
        self.clouds.sort(key=lambda c: c['z'], reverse=True)
        for c in self.clouds:
            c['z'] -= (7.0 + (2000 - c['z']) * 0.012)
            if c['z'] < 10:
                self.clouds.remove(c)
                self._add_cloud(2000)
                continue
            sc = 400 / (400 + c['z'])
            rx, ry = c['x'] * math.cos(tr) - c['y'] * math.sin(tr), c['x'] * math.sin(tr) + c['y'] * math.cos(tr)
            sx, sy, sz = cx + rx * sc, cy + ry * sc, c['s'] * sc
            if -sz < sx < Config.WIDTH + sz and -sz < sy < Config.HEIGHT + sz:
                cv = min(255, 40 + (2000 - c['z']) * 0.04 + self.flash)
                cs = pygame.Surface((int(sz*2.5), int(sz*2.5)), pygame.SRCALPHA)
                for i in range(5):
                    rad = sz * 0.5 * c['sv'][i]
                    pygame.draw.circle(cs, (cv, cv, min(255, cv+20), min(255, c['d'] * sc)//2),
                                     (int(sz + sz * 0.3 * math.cos(math.radians(c['r'] + i*72))),
                                      int(sz + sz * 0.3 * math.sin(math.radians(c['r'] + i*72)))), int(rad))
                surface.blit(cs, (int(sx - sz), int(sy - sz)))
                c['r'] += c['rs']
        pulse = math.sin(t * 0.005) * 0.1
        for i in range(12):
            p, np_ = i / 12, (i + 1) / 12
            rc, rn = p * 120 * (1 + pulse), np_ * 120 * (1 + pulse)
            sc, sn = 400 / (400 + p * 300), 400 / (400 + np_ * 300)
            rot = t * 0.003 + p * math.tau
            for j in range(16):
                a1, a2 = (j / 16) * math.tau + rot, ((j + 1) / 16) * math.tau + rot
                pts = [(cx + math.cos(a1) * rc * sc, cy + math.sin(a1) * rc * sc),
                       (cx + math.cos(a2) * rc * sc, cy + math.sin(a2) * rc * sc),
                       (cx + math.cos(a1) * rn * sn, cy + math.sin(a1) * rn * sn)]
                b = int(180 * (1 - p * 0.7))
                pygame.draw.line(surface, (b // 2, b, 255), pts[0], pts[1], 2)
                if i < 11:
                    pygame.draw.line(surface, (b // 2, b, 255), pts[0], pts[2], 1)
        if self.sw_alpha > 0:
            sw = pygame.Surface((Config.WIDTH, Config.HEIGHT), pygame.SRCALPHA)
            pygame.draw.circle(sw, (200, 240, 255, self.sw_alpha), (cx, cy), int(self.sw_rad), 3)
            surface.blit(sw, (0,0), special_flags=pygame.BLEND_ADD)
            self.sw_rad += 15
            self.sw_alpha -= 5
        if random.random() < 0.025:
            self.flash, self.sw_rad, self.sw_alpha = 230, 50, 150
            self.bolts.append({'s': self._bolt(random.randint(200, Config.WIDTH-200), -50, random.randint(0, Config.WIDTH), Config.HEIGHT+50, 5, 160), 'l': 12})
        for b in self.bolts[:]:
            b['l'] -= 1
            if b['l'] <= 0:
                self.bolts.remove(b)
                continue
            a = random.randint(150, 255)
            for p1, p2 in b['s']:
                pygame.draw.line(surface, (80, 150, 255, a//2), p1, p2, 6)
                pygame.draw.line(surface, (255, 255, 255, a), p1, p2, 2)
        shake = random.randint(-4, 4) if self.flash > 100 else 0
        txt = pygame.font.SysFont("Impact", 80).render("STORM EYE", True, (220, 240, 255) if self.flash < 150 else (255,255,255))
        surface.blit(txt, (cx - txt.get_width()//2 + shake, 40 + shake))

class CircularTextOrbit(EffectBase):
    def __init__(self):
        self.text = "                              STORM WARNING: MEGA DEMO APPROACHING. EXPECT TURBULENT CODE GUSTS UP TO 90FPS. HEAVY PIXEL RAINFALL DEVELOPING OVERHEAD                               "
        self.font = pygame.font.SysFont("Courier New", 72, bold=True)
        self.char_cache = {}
        self.char_surfs = [self._get_char_surf(c) for c in self.text]
        self.radius = 250
        self.st = None
        radius = 120.0
        height = 140.0
        self.bv = []
        for h in [-height/2, height/2]:
            for i in range(6):
                a = (i / 6.0) * math.tau
                self.bv.append([radius * math.cos(a), radius * math.sin(a), h])
        self.eds = [(i, (i + 1) % 6) for i in range(6)] + \
                   [(6 + i, 6 + ((i + 1) % 6)) for i in range(6)] + \
                   [(i, i + 6) for i in range(6)]
        self.rs = (random.uniform(0.0008, 0.0015),
                   random.uniform(0.0008, 0.0015),
                   random.uniform(0.0005, 0.0012))

    def _get_char_surf(self, char):
        if char not in self.char_cache:
            self.char_cache[char] = self.font.render(char, True, (255, 255, 255))
        return self.char_cache[char]

    def draw(self, surface, t):
        if self.st is None:
            self.st = t
        lt = t - self.st
        surface.fill((10, 10, 40))
        cx, cy = Config.CENTER
        ax, ay, az = lt * self.rs[0], lt * self.rs[1], lt * self.rs[2]
        cx_, sx, cy_, sy, cz, sz = math.cos(ax), math.sin(ax), math.cos(ay), math.sin(ay), math.cos(az), math.sin(az)
        pp = []
        FOCAL_LENGTH = 12000.0
        for x, y, z in self.bv:
            x, y = x * cz - y * sz, x * sz + y * cz
            x, z = x * cy_ - z * sy, x * sy + z * cy_
            y, z = y * cx_ - z * sx, y * sx + z * cx_
            if FOCAL_LENGTH + z != 0:
                sc = FOCAL_LENGTH / (FOCAL_LENGTH + z)
            else:
                sc = 1.0
            pp.append((cx + x * sc, cy + y * sc))
        c = pygame.Color(0)
        c.hsva = ((lt * 0.0005 % 1.0) * 360, 70, 100, 100)
        for e in self.eds:
            pygame.draw.line(surface, c, (int(pp[e[0]][0]), int(pp[e[0]][1])),
                           (int(pp[e[1]][0]), int(pp[e[1]][1])), 2)
        sp = (lt * 0.005) % len(self.text)
        for i in range(30):
            idx = int(sp + i) % len(self.text)
            a = ((i - (sp % 1.0)) / 30) * math.tau
            x, y = cx + self.radius * math.cos(a), cy + self.radius * math.sin(a)
            al = 255
            if i < 5:
                al = int(255 * (i / 5))
            elif i > 24:
                al = int(255 * (30 - i) / 6)
            s = pygame.transform.rotate(self.char_surfs[idx], -math.degrees(a) - 90).copy()
            s.fill((c.r, c.g, c.b, max(0, min(255, al))), special_flags=pygame.BLEND_RGBA_MULT)
            rect = s.get_rect(center=(int(x), int(y)))
            surface.blit(s, rect)

class UnrollingScroll(EffectBase):
    def __init__(self):
        self.img = None
        self.rect = None
        self.loaded = False
        try:
            if os.path.exists("storm.jpg"):
                i = pygame.image.load("storm.jpg").convert_alpha()
                nw = int(int(Config.HEIGHT * 0.7) * (i.get_width() / i.get_height()))
                self.img = pygame.transform.scale(i, (nw, int(Config.HEIGHT * 0.7)))
                self.rect = self.img.get_rect(center=Config.CENTER)
                self.loaded = True
        except:
            pass
        self.dur = 10000
        self.start_time = None

    def draw(self, surface, t):
        surface.fill((0, 0, 0))
        if not self.loaded:
            return
        if self.start_time is None:
            self.start_time = t
        el = t - self.start_time
        up = min(1.0, el / self.dur)
        rp = min(1.0, max(0, el - self.dur * 2) / self.dur)
        ox, oy = math.sin(t * 0.001) * 35, math.cos(t * 0.0008) * 18
        cw = int(self.rect.width * up)
        vs = self.img.subsurface(pygame.Rect(self.rect.width // 2 - cw // 2, 0, cw, self.rect.height)).copy()
        if rp > 0:
            sc = 1.0 - (rp * 0.98)
            if sc <= 0.01:
                return
            vs = pygame.transform.scale(vs, (max(1, int(vs.get_width() * sc)), max(1, int(vs.get_height() * sc))))
            vs = pygame.transform.rotate(vs, rp * 720)
            vs.set_alpha(int(255 * (1.0 - rp)))
        surface.blit(vs, vs.get_rect(center=(Config.WIDTH // 2 + ox, Config.HEIGHT // 2 + oy)))
        if rp == 0:
            lx = Config.WIDTH // 2 - cw // 2 - 15 + ox
            rx = Config.WIDTH // 2 + cw // 2 + ox
            pygame.draw.rect(surface, (140, 120, 80), (lx, self.rect.y - 10 + oy, 15, self.rect.height + 20))
            pygame.draw.rect(surface, (140, 120, 80), (rx, self.rect.y - 10 + oy, 15, self.rect.height + 20))
        if rp < 1.0:
            txt = pygame.font.SysFont("Impact", 52).render("STORM DATA DECODED", True, (230, 230, 255))
            txt.set_alpha(int(255 * (1.0 - rp)) if rp > 0 else int(255 * up))
            surface.blit(txt, (Config.WIDTH // 2 - txt.get_width() // 2, 30))

class VerticalScroller(EffectBase):
    def __init__(self):
        self.l = ["STORMY WEATHER MEGA DEMO", "RELEASED IN 2026", "", "", "PROMPT ARCHITECT", "PS@PS", "", "CODE ARCHITECTS", "THE GEN-AI BROTHERS", "", "MUSIC", "LIZARDKING (TRITON)", "", "VISUAL FX", "PYGAME ENGINE 2.6.1", "", "", "GREETINGS FLY TO", "", "CHATGPT", "CLAUDE", "LLAMA", "MISTRAL", "BERT", "", "", "THANK YOU FOR WATCHING", "STAY TUNED", "", "", "", ""]
        self.f = pygame.font.SysFont("Courier New", 48, bold=True)
        self.stars = []
        for _ in range(200):
            self.stars.append({
                'angle': random.uniform(0, math.tau),
                'dist': random.uniform(10, Config.WIDTH // 1.2),
                'speed': random.uniform(0.005, 0.015),
                'dir': random.choice([-1, 1]),
                'brightness': random.randint(150, 255)
            })
        self.st = None

    def draw(self, surface, t):
        surface.fill((10, 10, 30))
        cx, cy = Config.CENTER
        for s in self.stars:
            s['angle'] += s['speed'] * s['dir']
            x = cx + math.cos(s['angle']) * s['dist']
            y = cy + math.sin(s['angle']) * s['dist']
            if 0 <= x < Config.WIDTH and 0 <= y < Config.HEIGHT:
                pygame.draw.circle(surface, (s['brightness'],) * 3, (int(x), int(y)), 1)
        if self.st is None:
            self.st = t
        elapsed = t - self.st
        curr = (elapsed * 0.06 + len(self.l) * 40 + Config.HEIGHT) % (len(self.l) * 40 + Config.HEIGHT)
        sy = Config.HEIGHT - curr
        for i, l in enumerate(self.l):
            y = sy + i * 40
            if -50 < y < Config.HEIGHT + 50:
                sh = self.f.render(l, True, (0, 0, 0))
                surface.blit(sh, (Config.WIDTH//2 - sh.get_width()//2 + 3, y + 3))
                blue_pulse = int(155 + 100 * math.sin(elapsed * 0.005 + i * 0.5))
                surface.blit(self.f.render(l, True, (100, 200, blue_pulse)), (Config.WIDTH//2 - sh.get_width()//2, y))
        surface.blit(pygame.font.SysFont("Impact", 40).render("CREDITS", True, (255, 255, 200)), (20, 20))

class StartScreen(EffectBase):
    def __init__(self):
        self.tf = pygame.font.SysFont("Impact", 100)
        self.sf = pygame.font.SysFont("Courier", 40, bold=True)
        self.cf = pygame.font.SysFont("Impact", 48)
        self.txt = "STORMY WEATHER MEGA DEMO"
        self.sub_txt = "BROUGHT TO YOU BY PS@PS & THE GEN-AI BROTHERS"
        self.scroll_msg = "                    ***     LET'S GET STARTED WITH THE DEMO      ***      DURING THE DEMO, PRESS THE  >>>SPACE BAR<<<  TO MOVE TO THE NEXT SCENE      ***      ENJOY THE SHOW      ***                    "
        self.scroll_color = (255, 255, 0)
        self.scroll_surf = self.cf.render(self.scroll_msg, True, self.scroll_color).convert_alpha()
        self.scroll_w = self.scroll_surf.get_width()
        self.bg_img = None
        try:
            if os.path.exists("title.jpg"):
                raw_img = pygame.image.load("title.jpg").convert()
                img_ratio = raw_img.get_width() / raw_img.get_height()
                screen_ratio = Config.WIDTH / Config.HEIGHT
                if img_ratio > screen_ratio:
                    new_h = Config.HEIGHT
                    new_w = int(new_h * img_ratio)
                else:
                    new_w = Config.WIDTH
                    new_h = int(new_w / img_ratio)
                self.bg_img = pygame.transform.smoothscale(raw_img, (new_w, new_h))
        except Exception as e:
            print(f"Could not load title.jpg: {e}")
        self.sub_y = -100
        self.sub_vy = 0
        self.gravity = 0.35
        self.bounce = 0.65
        self.target_y = Config.CENTER[1] + 60
        self.bounce_done = False
        self.explosion_start_time = None

    def draw(self, surface, t):
        cx, cy = Config.CENTER
        is_exploding = False
        ex_t = 0
        if self.explosion_start_time is not None:
            is_exploding = True
            ex_t = t - self.explosion_start_time
        elif t > (Config.TITLE_TIME_MS - 3000):
            is_exploding = True
            ex_t = t - (Config.TITLE_TIME_MS - 3000)
        surface.fill((0, 0, 0))
        if self.bg_img:
            if is_exploding:
                alpha = clamp(255 - (ex_t / 3000) * 255)
            else:
                fade_in_duration = 10000
                alpha = clamp((t / fade_in_duration) * 255)
            temp_bg = self.bg_img.copy()
            temp_bg.set_alpha(alpha)
            surface.blit(temp_bg, ((Config.WIDTH - self.bg_img.get_width())//2, (Config.HEIGHT - self.bg_img.get_height())//2))
        if not self.bounce_done:
            if t < 10000:
                self.sub_vy += self.gravity
                self.sub_y += self.sub_vy
                if self.sub_y > self.target_y:
                    self.sub_y = self.target_y
                    self.sub_vy *= -self.bounce
            else:
                self.sub_y = self.target_y
                self.bounce_done = True
        total_w = sum(self.tf.render(c, True, (0,0,0)).get_width() for c in self.txt)
        tx = cx - total_w // 2
        ty = cy - 100
        for i, c in enumerate(self.txt):
            wy = 20 * math.sin(i * 0.3 + t * 0.004)
            char_x, char_y = tx, ty + wy
            c_scale, c_alpha = 1.0, 255
            if is_exploding:
                angle = (i / len(self.txt)) * math.pi - math.pi
                spd = 0.7 * ex_t
                char_x += math.cos(angle) * spd
                char_y += math.sin(angle) * spd
                c_scale = 1.0 + (ex_t / 350)
                c_alpha = max(0, 255 - (ex_t // 10))
            h = (i * 0.08 + t * 0.001) % 1.0
            col = (int(200 + 55 * math.sin(h * math.tau)),
                   int(200 + 55 * math.sin(h * math.tau + math.tau/3)),
                   int(220 + 35 * math.sin(h * math.tau + 2*math.tau/3)))
            cs = self.tf.render(c, True, col)
            gs = self.tf.render(c, True, (col[0]//2, col[1]//2, col[2]//2))
            if c_scale != 1.0:
                new_sz = (max(1, int(cs.get_width()*c_scale)), max(1, int(cs.get_height()*c_scale)))
                cs = pygame.transform.smoothscale(cs, new_sz)
                gs = pygame.transform.smoothscale(gs, new_sz)
            cs.set_alpha(c_alpha)
            gs.set_alpha(c_alpha)
            for ox, oy in [(-2, -2), (2, -2), (-2, 2), (2, 2)]:
                surface.blit(gs, (char_x + ox, char_y + oy))
            surface.blit(cs, (char_x, char_y))
            tx += self.tf.render(c, True, (0,0,0)).get_width()
        sub_col = (150, 200, clamp(200 + 55 * math.sin(t * 0.003)))
        ss = self.sf.render(self.sub_txt, True, sub_col)
        curr_sub_y = self.sub_y
        s_alpha = 255
        if is_exploding:
            s_alpha = max(0, 255 - (ex_t // 8))
            s_scale = 1.0 + (ex_t / 450)
            ss = pygame.transform.smoothscale(ss, (int(ss.get_width()*s_scale), int(ss.get_height()*s_scale)))
            ss.set_alpha(s_alpha)
            curr_sub_y += (ex_t * 0.2)
        bg_rect = ss.get_rect(center=(cx, int(curr_sub_y) + ss.get_height()//2))
        sub_bg = pygame.Surface((bg_rect.width + 20, bg_rect.height + 10), pygame.SRCALPHA)
        sub_bg.fill((0, 0, 0, int(s_alpha * 0.4)))
        surface.blit(sub_bg, (bg_rect.x - 10, bg_rect.y - 5))
        surface.blit(ss, bg_rect)
        if t > 10000:
            scroll_speed = 0.25
            scroll_dist = (t - 10000) * scroll_speed
            total_loop_width = self.scroll_w + Config.WIDTH
            scr_x = Config.WIDTH - (scroll_dist % total_loop_width)
            scr_y = Config.HEIGHT - 80
            scr_alpha = 255
            if is_exploding:
                scr_y += (ex_t * 0.5)
                scr_alpha = max(0, 255 - (ex_t // 5))
            if scr_alpha > 0:
                sbg_rect = self.scroll_surf.get_rect(topleft=(scr_x, scr_y))
                if sbg_rect.right > 0 and sbg_rect.left < Config.WIDTH:
                    scr_bg = pygame.Surface((sbg_rect.width + 20, sbg_rect.height + 10), pygame.SRCALPHA)
                    scr_bg.fill((0, 0, 0, int(scr_alpha * 0.4)))
                    if is_exploding:
                        self.scroll_surf.set_alpha(scr_alpha)
                    surface.blit(scr_bg, (sbg_rect.x - 10, sbg_rect.y - 5))
                    surface.blit(self.scroll_surf, sbg_rect)

class MegaEndScreen:
    def __init__(self, audio_sys):
        self.audio = audio_sys
        self.ef = pygame.font.Font(None, 360)
        self.p2d, self.p3d = 4000, 4000
        self.parts = []
        self.exp, self.snd, self.faded = False, False, False

    def draw(self, surface, t):
        if t < self.p2d:
            surface.fill((0, 0, 0))
            if not self.faded:
                self.audio.fadeout_music(self.p2d)
                self.faded = True
            a = int(255 * (t / 1000)) if t < 1000 else 255
            et = self.ef.render("THE END", True, (255, 255, 255))
            es = pygame.Surface(et.get_size(), pygame.SRCALPHA)
            es.blit(et, (0, 0))
            es.set_alpha(a)
            surface.blit(es, et.get_rect(center=Config.CENTER))
        elif t < self.p2d + self.p3d:
            pt = t - self.p2d
            surface.fill((0, 0, 0))
            if not self.exp:
                self.exp = True
                self.audio.play_explosion()
                r = self.ef.render("THE END", True, (255, 255, 255)).get_rect(center=Config.CENTER)
                for _ in range(500):
                    self.parts.append(ExplosionParticle(random.randint(r.left - 50, r.right + 50), random.randint(r.top - 50, r.bottom + 50), r.width, r.height))
            self.parts = [p for p in self.parts if p.update()]
            for p in self.parts:
                p.draw(surface)
            ta = 255 if pt < 500 else (int(255 * (1 - (pt - 500) / 1500)) if pt < 2000 else 0)
            if ta > 0:
                et = self.ef.render("THE END", True, (255, 255, 255))
                es = pygame.Surface(et.get_size(), pygame.SRCALPHA)
                es.blit(et, (0, 0))
                es.set_alpha(ta)
                surface.blit(es, et.get_rect(center=Config.CENTER))

class DemoEngine:
    def __init__(self):
        parse_args()
        pygame.init()
        if Config.FULLSCREEN:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            Config.WIDTH, Config.HEIGHT = self.screen.get_size()
        else:
            self.screen = pygame.display.set_mode((Config.BASE_WIDTH, Config.BASE_HEIGHT))
            Config.WIDTH, Config.HEIGHT = Config.BASE_WIDTH, Config.BASE_HEIGHT
        Config.CENTER = (Config.WIDTH // 2, Config.HEIGHT // 2)
        pygame.display.set_caption("STORMY WEATHER MEGA DEMO")
        self.clock = pygame.time.Clock()
        self.running = True
        self.audio = AudioSystem()
        self.trail_surf = pygame.Surface((Config.WIDTH, Config.HEIGHT))
        self.trail_surf.set_alpha(60)
        self.scan_surf = pygame.Surface((Config.WIDTH, Config.HEIGHT), pygame.SRCALPHA)
        for y in range(0, Config.HEIGHT, 2):
            pygame.draw.line(self.scan_surf, (0, 0, 0, 40), (0, y), (Config.WIDTH, y))
        self.start_screen = StartScreen()
        self.end_screen = MegaEndScreen(self.audio)
        self.effects = [
            HardcoreRubberDeformer(), AdvancedPlasma(), BouncingRadar(),
            ElectricStormOrb(), StormEye(), CircularTextOrbit(),
            UnrollingScroll(), VerticalScroller()
        ]
        self.state = "PRE"
        self.timer = 0
        self.start_ticks = pygame.time.get_ticks()
        self.curr_effect_idx = 0
        self.effect_start_time = 0
        self.last_beep = -1

    def run(self):
        while self.running:
            self._handle_events()
            self._update()
            self._draw()
            self.clock.tick(Config.FPS)
        self.audio.stop_music()
        pygame.quit()
        sys.exit()

    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.audio.stop_music()
                    if self.state == "TITLE":
                        self.state = "END"
                        self.start_ticks = pygame.time.get_ticks() - self.end_screen.p2d
                    elif self.state == "END":
                        self.running = False
                    else:
                        self.state = "END"
                        self.start_ticks = pygame.time.get_ticks() - self.end_screen.p2d
                        self.audio.stop_music()
                elif event.key == pygame.K_SPACE:
                    if self.state == "TITLE":
                        current_t = pygame.time.get_ticks() - self.start_ticks
                        if self.start_screen.explosion_start_time is None:
                            self.start_screen.explosion_start_time = current_t
                            Config.TITLE_TIME_MS = current_t + 3000
                    elif self.state == "DEMO":
                        self._next_effect()
                elif event.key == pygame.K_m:
                    self.audio.toggle_pause()
                elif event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS:
                    self.audio.adjust_volume(0.1)
                elif event.key == pygame.K_MINUS:
                    self.audio.adjust_volume(-0.1)

    def _start_demo(self):
        self.state = "DEMO"
        self.start_ticks = pygame.time.get_ticks()
        self.effect_start_time = pygame.time.get_ticks()
        self.curr_effect_idx = 0
        if isinstance(self.effects[7], UnrollingScroll):
            self.effects[7].start_time = None

    def _next_effect(self):
        self.curr_effect_idx = (self.curr_effect_idx + 1) % len(self.effects)
        self.effect_start_time = pygame.time.get_ticks()
        if self.curr_effect_idx == 7 and isinstance(self.effects[7], UnrollingScroll):
            self.effects[7].start_time = None
        if self.curr_effect_idx == 0:
            self.state = "END"
            self.start_ticks = pygame.time.get_ticks()

    def _update(self):
        if self.state == "PRE":
            self.timer += 1
            if self.timer >= 30:
                self.state = "COUNT"
                self.timer = 0
        elif self.state == "COUNT":
            self.timer += 1
            rem = 5 - (self.timer // 60)
            if rem != self.last_beep and rem > 0:
                self.audio.play_countdown(rem)
                self.last_beep = rem
            if self.timer >= 300:
                self.state = "TITLE"
                self.start_ticks = pygame.time.get_ticks()
                self.audio.play_music()
        elif self.state == "TITLE":
            if pygame.time.get_ticks() - self.start_ticks > Config.TITLE_TIME_MS:
                self._start_demo()
        elif self.state == "DEMO":
            if pygame.time.get_ticks() - self.effect_start_time > Config.AUTO_ADVANCE_MS:
                self._next_effect()
        elif self.state == "END":
            elapsed = pygame.time.get_ticks() - self.start_ticks
            if elapsed > self.end_screen.p2d + self.end_screen.p3d:
                self.running = False

    def _draw(self):
        self.screen.fill((0, 0, 0))
        if self.state == "PRE":
            pass
        elif self.state == "COUNT":
            rem = max(1, 5 - (self.timer // 60))
            ts = pygame.font.SysFont("Impact", 180).render(str(rem), True, (255, 255, 255))
            tr = ts.get_rect(center=Config.CENTER)
            if self.timer % 60 < 10:
                pr = 200 + 50 * (1.0 - (self.timer % 60) / 10)
                pygame.draw.circle(self.screen, (255, 255, 255), Config.CENTER, int(pr), 4)
            self.screen.blit(ts, tr)
        elif self.state == "TITLE":
            self.start_screen.draw(self.screen, pygame.time.get_ticks() - self.start_ticks)
        elif self.state == "DEMO":
            self.screen.blit(self.trail_surf, (0,0))
            t = pygame.time.get_ticks() - self.start_ticks
            self.effects[self.curr_effect_idx].draw(self.screen, t)
            self._draw_overlay()
        elif self.state == "END":
            self.end_screen.draw(self.screen, pygame.time.get_ticks() - self.start_ticks)
        self.screen.blit(self.scan_surf, (0,0))
        pygame.display.flip()

    def _draw_overlay(self):
        font = pygame.font.SysFont("Arial", 24)
        names = ["HARDCORE RUBBER DEFORMER", "CHANGING WEATHER", "WEATHER RADAR", "ELECTRIC STORM ORB", "STORM EYE", "TEXT ORBIT", "UNROLLING", "VERTICAL CREDITS"]
        nm = names[self.curr_effect_idx] if self.curr_effect_idx < len(names) else "UNKNOWN"
        txt_nm = font.render(nm, True, (255, 255, 200))
        self.screen.blit(txt_nm, (Config.WIDTH - txt_nm.get_width() - 20, 20))
        self.screen.blit(font.render(f"SCENE {self.curr_effect_idx + 1}/{len(self.effects)}", True, (200, 200, 255)), (20, Config.HEIGHT - 70))
        rem = max(0, (Config.AUTO_ADVANCE_MS - (pygame.time.get_ticks() - self.effect_start_time)) // 1000)
        self.screen.blit(font.render(f"AUTO-ADVANCE: {rem}s", True, (180, 180, 220)), (20, Config.HEIGHT - 40))
        if self.audio.mod_loaded:
            ht = pygame.font.SysFont("Arial", 16).render("M: TOGGLE MUSIC | +/-: VOLUME", True, (150, 255, 150))
            self.screen.blit(ht, (Config.WIDTH - ht.get_width() - 20, Config.HEIGHT - 30))

if __name__ == "__main__":
    DemoEngine().run()