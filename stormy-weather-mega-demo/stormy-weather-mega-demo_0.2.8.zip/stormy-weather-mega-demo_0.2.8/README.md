# Stormy Weather Mega Demo

A high-intensity Mega Demo showcasing real-time visual effects, procedural audio, and multiple animated scenes. This project is inspired by classic 1990s demo scene productions, pushing Python and Pygame to their limits with heavy maths, shaders-by-hand, and timing-based transitions. You can find more information in the related blog post [Revisiting the Demoscene: From Amiga Dreams to AI-Powered Reality](https://people.cs.nott.ac.uk/pszps/misc.html#post02). It also contains a video of the Mega Demo.

## Features

- Multiple full-screen visual effects and scenes
- Procedural audio (beeps, explosions) generated at runtime
- Optional background music playback (.mod file)
- Scene auto-advance with manual override
- Fullscreen or windowed mode
- Heavy use of trigonometry, vector maths, and numpy

## Requirements

- Python>=3.10
- pygame>=2.6.1
- numpy>=1.24.0

## Installation

1. Create a virtual environment (recommended)
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the Demo

```bash
python mega-demo-v0.2.8.py
```

Optional fullscreen mode:

```bash
python mega-demo-v0.2.8.py --fullscreen
```

## Controls

- **SPACE**: Advance to next scene
- **ESC / Close Window**: Exit demo
- **M**: Toggle music pause/unpause
- **+/-**: Adjust music volume

## Assets

Optional external files (not required, but enhance the experience):

- `elimination.mod` – background music
- `title.jpg` – title screen image
- `storm.jpg` – scroll effect image

If these files are missing, the demo will still run. The 'elimination.mod' file is not part of this release. It needs to be downloaded from the Mod Archive. Here is the [direct link](https://modarchive.org/index.php?request=view_by_moduleid&query=106736).

## License

MIT License - see [LICENSE.md](LICENSE.md) for details.

## Version

Current version: 0.2.8